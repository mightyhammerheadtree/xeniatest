#!/bin/bash
# build.sh -- WASM/browser build of the Sonic Generations recomp port.
#
# Pipeline:
#   1. Emscripten toolchain (emsdk latest)
#   2. rexglue-sdk v0.10.0 + submodules + emscripten patch (this dir)
#   3. Stage generated recompiled code + apply the wasm overload rewrite
#   4. CMake configure (SDK as subproject, WebGPU backend, pthreads+JSPI)
#   5. Build -> sonicgenerations.{js,wasm} into web/
#
# Usage:  bash emscripten/build.sh [--jobs N]
#         WASM_CONFIGURE_ONLY=1  -> stop after the CMake configure step
# Output: build/web/  ->  copy sonicgenerations.js + sonicgenerations.wasm
#         next to web/index.html and serve with web/serve.py.
set -euo pipefail

PRJ="$(cd "$(dirname "$0")/.." && pwd)"
GAME="${GAME_DIR:-$PRJ/../Sonic-Generations-recomp-android-and-pc-edition}"
SDK_ROOT="${REXGLUE_SDK_DIR:-$PRJ/../rexglue-sdk}"
SDK_VER="v0.10.0"
# NOTE: deliberately NOT named "EMSDK_DIR". Sourcing emsdk_env.sh runs
# `emsdk construct_env`, which emits `unset <VAR>` for every environment
# variable starting with EMSDK_ that emsdk does not itself manage (see
# construct_env_with_vars in emsdk.py). Under `set -u`, any later $EMSDK_DIR
# reference would die with "unbound variable". The workflow's EMSDK_DIR env
# override is still honored -- it is read here, before the source.
WASM_EMSDK_DIR="${WASM_EMSDK_DIR:-${EMSDK_DIR:-$PRJ/../emsdk}}"
BUILD_DIR="$PRJ/build/web"
JOBS="$(nproc)"
while [[ $# -gt 0 ]]; do
  case "$1" in
    --jobs) JOBS="$2"; shift 2 ;;
    *) shift ;;
  esac
done
STAMP="$SDK_ROOT/.emscripten-patched"

echo "=== [1/5] Emscripten toolchain ==="
if [ ! -x "$WASM_EMSDK_DIR/emsdk" ]; then
  git clone --depth 1 https://github.com/emscripten-core/emsdk.git "$WASM_EMSDK_DIR"
fi
export EMSDK_QUIET=1
# A fresh emsdk clone has no toolchain installed: emsdk_env.sh only puts emcc
# on PATH once install+activate have run, so bootstrap first when needed.
if [ ! -x "$WASM_EMSDK_DIR/upstream/emscripten/emcc" ]; then
  echo "[build] emsdk: installing + activating latest toolchain (first run only)"
  "$WASM_EMSDK_DIR/emsdk" install latest
  "$WASM_EMSDK_DIR/emsdk" activate latest
fi
# shellcheck disable=SC1091
source "$WASM_EMSDK_DIR/emsdk_env.sh"
if ! command -v emcc >/dev/null 2>&1; then
  echo "ERROR: emcc is not on PATH after sourcing $WASM_EMSDK_DIR/emsdk_env.sh" >&2
  echo "       emsdk state: $(ls "$WASM_EMSDK_DIR" 2>/dev/null | tr '\n' ' ')" >&2
  exit 1
fi
emcc --version | head -1

echo "=== [2/5] rexglue-sdk $SDK_VER + emscripten patch ==="
if [ ! -d "$SDK_ROOT/src" ]; then
  git clone --depth 1 --branch "$SDK_VER" https://github.com/rexglue/rexglue-sdk.git "$SDK_ROOT"
fi
# Submodules required to compile core + generated code (GPU/video giants are
# pulled only when their backends are enabled; WebGPU needs none of them).
# libmspack/FFmpeg/sdl3 are in the SDK's unconditional REQUIRED_SUBMODULES
# check (thirdparty/CMakeLists.txt) even when the wasm build never links them.
for m in fmt spdlog tomlplusplus simde xxHash utfcpp stb imgui o1heap \
         disruptorplus inja cli11 aes_128 tiny-aes-c crypto pe disasm \
         vulkan-headers spirv-headers glslang renderdoc catch2 \
         libmspack FFmpeg sdl3; do
  git -C "$SDK_ROOT" submodule update --init --depth 1 "thirdparty/$m"
done
# FFmpeg (WMA Pro decoder) is built without a configure step: the submodule
# vendors per-platform config headers but none for Emscripten. Copy the wasm
# config + dispatch stub over the submodule files on every run (idempotent,
# survives SDK cache restores that ship the upstream stubs).
mkdir -p "$SDK_ROOT/thirdparty/FFmpeg"
cp "$PRJ/emscripten/ffmpeg/config_emscripten.h" \
   "$SDK_ROOT/thirdparty/FFmpeg/config_emscripten.h"
cp "$PRJ/emscripten/ffmpeg/config.h" "$SDK_ROOT/thirdparty/FFmpeg/config.h"
echo "[build] FFmpeg wasm config installed"
if [ ! -f "$STAMP" ]; then
  echo "[build] applying emscripten patch"
  git -C "$SDK_ROOT" apply --whitespace=nowarn \
      "$PRJ/emscripten/rexglue-sdk-v0.10.0-emscripten.patch"
  touch "$STAMP"
fi

echo "=== [3/5] Stage generated code + wasm overload rewrite ==="
GEN_SRC="$GAME/port/generated/default"
GEN_DST="$BUILD_DIR/generated/default"
if [ ! -f "$GAME/port/src/main.cpp" ] || [ ! -d "$GEN_SRC" ]; then
  echo "ERROR: generated game code not found at $GAME" >&2
  echo "       Expected the Sonic-Generations-recomp checkout with:" >&2
  echo "         $GEN_SRC/*.cpp" >&2
  echo "         $GAME/port/src/main.cpp" >&2
  echo "       Point GAME_DIR at your checkout, e.g.:" >&2
  echo "         GAME_DIR=\$GITHUB_WORKSPACE/game bash harness/emscripten/build.sh" >&2
  exit 1
fi
mkdir -p "$GEN_DST" "$BUILD_DIR/app"
cp "$GEN_SRC"/*.cpp "$GEN_SRC"/*.h "$GEN_DST/"
cp "$GAME/port/src/main.cpp" "$GAME/port/src/sonicgenerations_app.h" "$BUILD_DIR/app/"
cp "$GAME/port/"sonicgenerations_*.toml "$BUILD_DIR/" 2>/dev/null || true
# On wasm+SIMD128 simde maps __m128/__m128i to the same v128_t; the
# movemask_epi8 call sites emitted by the vector builder are rewritten to the
# explicit setFromMaskInt variant added by the patch (see context.h).
grep -rl 'setFromMask(simde_mm_load_si128((simde__m128i\*)' "$GEN_DST" | while read -r f; do
  sed -i 's/setFromMask(simde_mm_load_si128((simde__m128i\*)/setFromMaskInt(simde_mm_load_si128((simde__m128i*)/g' "$f"
done
echo "[build] setFromMaskInt rewrite applied to $(grep -rl setFromMaskInt "$GEN_DST" | wc -l) files"

echo "=== [4/5] CMake configure ==="
cmake -B "$BUILD_DIR" -S "$PRJ/emscripten" \
  -DCMAKE_TOOLCHAIN_FILE="$WASM_EMSDK_DIR/upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake" \
  -DCMAKE_BUILD_TYPE=Release \
  -DREXGLUE_SDK_DIR="$SDK_ROOT" \
  -DREXGLUE_APP_SRC_DIR="$BUILD_DIR" \
  -DREXGLUE_USE_WEBGPU=ON \
  -DREXGLUE_ENABLE_TRACY=OFF \
  -DREXGLUE_ENABLE_PERF_COUNTERS=OFF \
  -DREXGLUE_BUILD_TESTS=OFF

if [ "${WASM_CONFIGURE_ONLY:-0}" = "1" ]; then
  echo "[build] WASM_CONFIGURE_ONLY=1 -> configure succeeded, skipping build step"
  exit 0
fi

echo "=== [5/5] Build ==="
cmake --build "$BUILD_DIR" -j "$JOBS"
echo "[build] done -> $BUILD_DIR/sonicgenerations.{js,wasm}"
